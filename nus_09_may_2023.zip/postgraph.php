<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NUS FRS System | Generate Report</title>
    <link rel="icon" href="img/social-square-n-blue.png" />
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <link rel="stylesheet" type="text/css" href="css/generategraph.css">
   
</head>
<body>
    <a href ="export.php?id=<?php echo $_POST['supplierid']; ?>" class="export">Export to Excel</a>
    <button class="pdf" onclick="printpage();">Export to PDF</button>
    <?php
        include('dbconn.php');
        
        $clien = $_POST['supplierid'];

        $sql = "SELECT nus_supply_contract.*, clientcompanydata.* FROM nus_supply_contract 
        INNER JOIN clientcompanydata ON clientcompanydata.id = nus_supply_contract.clientId 
        WHERE supplierId=$clien;";

        $result = mysqli_query($conn,$sql);

    ?>

    <ul>
        <?php
            while($row = mysqli_fetch_assoc($result)) {
        ?>
            <li>
                <span>CONTRACT SUMMARY REPORT</span>
                <h2><?php echo $row['contract_id']; ?></h2>
            </li>
            <li>
                <span>CLIENT NAME</span>
                <h2><?php echo $row['clientcompany']; ?></h2>
            </li>
            <br>
            <li class="supplierClass">
                <span>SUPPLIER</span>
                <h2><?php echo $row['supplyName']; ?><span ><img src="img/supplier.svg" class="suppic" alt="supplier Icon"></span></h2>
            </li>
                <?php
                    if($row['contractType'] == 'fixed') {
                ?>
                <li class="">
                    <span>COMMODITY</span>
                    <h2><?php echo $row['commodityName'];?> <span class="spaneleCom"><?php echo $row['contractType'];?></span><span c><img src="img/elecrticity.svg" class="elecic" alt="Electricity Icon"></span></h2>
                </li>
                <?php
                } else {
                ?>
                <li class="gasClass">
                    <span>COMMODITY</span>
                    <h2><?php echo $row['commodityName'];?> <span class="spangasCom"> <?php echo $row['contractType'];?></span><span ><img src="img/gas.svg" class="gasic" alt="gas Icon"></span></h2>
                </li>
                <?php
                }
                ?>
            </li>
            <li class="reportPeriod">
                <span>REPORT PERIOD</span>
                <h2><?php echo $row['contractTermfromDate']; ?><span><img src="img/calendar.svg" class="caleic" alt="calendar Icon"></span></h2>
            </li>
            <li class="countryFlag">
                <span>COUNTRY</span>
                <h2><?php echo $row['countryName']; ?><span ><img src="img/countryflag.svg" class="countryic" alt="countryflag Icon"></span></h2>
            </li>
            <li>
                <span>CONTRACT CONSUMPTION (MWH)</span>
                <h2><?php echo $row['totalAnualConsumption']; ?></h2>
            </li>
            <li>
                <span>CURRENCY</span>
                <h2><?php echo $row['contractpricetype']; ?></h2>
            </li>
            <?php
                function myFunc($r) {
                    $res='';
                    $comm = explode(",",$r);
                    $maxcount = count($comm);
                    for($i=0; $i<$maxcount; $i++) {
                        $res = $res.$comm[$i];
                    }
                    return $res;
                }
                $str = $row['consumptionmonth'];
                $price = $row['commodityPrice'];
                $comm = array(explode("|",$str));

                $arcount = count($comm);
                $maxcount = count($comm[0]);
                $input = array (
                "year"=>array (),
                "month"=>array (),
                "consumption"=>array (),
                "price"=>array ()
                );

                for($i=0; $i<$maxcount; $i++) {

                $conn = array(explode("-",$comm[0][$i]));
                array_push($input['year'],$conn[0][1]);
                array_push($input['month'], $conn[0][0]);
                array_push($input['consumption'], myFunc($conn[0][2]));
                array_push($input['price'], $price);

                }
            ?>
        <?php
            }
        ?>
    </ul>
    <div id="top_x_div" style="width: 900px; height: 500px;"></div>
    <table>
        <thead>
            <th></th>
            <?php
                $countMonth = count($input['month']);
                for($i=0; $i<$countMonth; $i++) {
                    echo "<th>";
                    echo $input['month'][$i];
                    echo "</th>";
                }
            ?>
            <th>Total</th>
        </thead>
        <tbody>
            <tr>
                <td style = "width:20%;">Est. Consumption (MWh)</td>
                <?php
                    $countMonth = count($input['month']);
                    for($i=0; $i<$countMonth; $i++) {
                        echo "<td>";
                        $consumption = $input['consumption'][$i];
                        $regex = "/\B(?=(\d{3})+(?!\d))/i";
                        echo $usdformat = preg_replace($regex, ",", $consumption);
                        echo "</td>";
                    }
                ?>
                <td>
                    <?php 
                        echo number_format($input['consumption'][0]*12);
                    ?>
                </td>
            </tr>
            <tr>
                <td style = "width:20%;">Hedged Consumption (MWh)</td>
                <?php
                    $countCons = count($input['consumption']);
                    for($i=0; $i<$countCons; $i++) {
                        echo "<td>";
                        $consumption = $input['consumption'][$i];
                        $regex = "/\B(?=(\d{3})+(?!\d))/i";
                        echo $usdformat = preg_replace($regex, ",", $consumption);
                        echo "</td>";
                    }
                ?>
                <td>
                    <?php 
                        echo number_format($input['consumption'][0]*12);
                    ?>
                </td>
            </tr>
            <tr>
                <td style = "width:20%;">Open Consumption (MWh)</td>
                <?php
                    $countCons = count($input['consumption']);
                    for($i=0; $i<$countCons; $i++) {
                        echo "<td>";
                        echo $input['consumption'][$i]-$input['consumption'][$i];
                        echo "</td>";
                    }
                ?>
                <td>0</td>
            </tr>
            <tr>
                <td style = "width:20%;">% Hedged</td>
                <?php
                    $countCons = count($input['consumption']);
                    for($i=0; $i<$countCons; $i++) {
                        echo "<td>";
                        // echo $input['consumption'][$i]-$input['consumption'][$i]*100;
                        echo 100;
                        echo "</td>";
                    }
                ?>
                <td>
                    100
                </td>
            </tr>
            <tr>
                <td style = "width:20%;">% Open</td>
                <?php
                    $countCons = count($input['consumption']);
                    for($i=0; $i<$countCons; $i++) {
                        echo "<td>";
                        echo abs($input['consumption'][$i]-$input['consumption'][$i])*100;
                        echo "</td>";
                    }
                ?>
                <td>0</td>
            </tr>
            <tr>
                <td style = "width:20%;">Fixed Commodity Price (per MWh)</td>
                <?php
                    $countCons = count($input['price']);
                    for($i=0; $i<$countCons; $i++) {
                        echo "<td>";
                        echo $input['price'][$i];
                        echo "</td>";
                    }
                ?>
                <td>
                    <?php
                        echo $input['price'][0]*12;
                    ?>
                </td>
            </tr>
            <tr>
                <td style = "width:20%;">Port Effective Price (Hedged + Unhedged)</td>
                <?php
                    $countCons = count($input['price']);
                    for($i=0; $i<$countCons; $i++) {
                        echo "<td>";
                        echo $input['price'][$i];
                        echo "</td>";
                    }
                ?>
                <td>
                    <?php
                        echo $input['price'][0]*12;
                    ?>
                </td>
            </tr>
            <tr class="protofilo">
                <td style = "width:20%;">Est. Portfolio <br>Commodity Cost</td>
                <?php
                    $countCons = count($input['price']);
                    for($i=0; $i<$countCons; $i++) {
                        echo "<td>";
                        echo number_format(($input['price'][$i]*$input['consumption'][$i]),2);
                        echo "</td>";
                    }
                ?>
                <td>
                    <?php
                        $totalConsumption = myFunc(number_format(($input['consumption'][0]*12)));
                        $totalAmount = $input['price'][0]*12;
                        $finalAmount = $totalAmount * $totalConsumption;
                        $regex = "/\B(?=(\d{3})+(?!\d))/i";
                        $usdformat = preg_replace($regex, ",", $finalAmount);
                        echo $usdformat;
                        //echo $finalAmount;
                    ?>
                </td>
            </tr>
        </tbody>
    </table>
</body>
<script>
          google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawStuff);

      function drawStuff() {
        var data = new google.visualization.arrayToDataTable([
          ['Month', 'MWh'],
          ["<?php echo $input['month'][0]; ?>", "<?php echo $input['consumption'][0]?>"],
          ["<?php echo $input['month'][1]; ?>", "<?php echo $input['consumption'][1]?>"],
          ["<?php echo $input['month'][2]; ?>", "<?php echo $input['consumption'][2]?>"],
          ["<?php echo $input['month'][3]; ?>", "<?php echo $input['consumption'][3]?>"],
          ["<?php echo $input['month'][4]; ?>", "<?php echo $input['consumption'][4]?>"],
          ["<?php echo $input['month'][5]; ?>", "<?php echo $input['consumption'][5]?>"],
          ["<?php echo $input['month'][6]; ?>", "<?php echo $input['consumption'][6]?>"],
          ["<?php echo $input['month'][7]; ?>", "<?php echo $input['consumption'][7]?>"],
          ["<?php echo $input['month'][8]; ?>", "<?php echo $input['consumption'][8]?>"],
          ["<?php echo $input['month'][9]; ?>", "<?php echo $input['consumption'][9]?>"],
          ["<?php echo $input['month'][10]; ?>", "<?php echo $input['consumption'][10]?>"],
          ["<?php echo $input['month'][11]; ?>", "<?php echo $input['consumption'][11]?>"]
        ]);

        var options = {
          title: 'Hedged Position Chart',
          width: 900,
          legend: { position: 'none' },
          chart: { title: 'Hedged Consumption Chart',
                   subtitle: 'consumption in MWh' },
          bars: 'vertical', // Required for Material Bar Charts.
          axes: {
            x: {
              0: { side: 'bottom', label: 'Months'} // Top x-axis.
            },
            y: {
              0: { side: 'top', label: 'Total Consumption (MWh)'}
            }
            
          },
          bar: { groupWidth: "90%" }
        };

        var chart = new google.charts.Bar(document.getElementById('top_x_div'));
        chart.draw(data, options);
      };
</script>
<script>
        function printpage() {
            window.print();
        }
    </script>
</html>