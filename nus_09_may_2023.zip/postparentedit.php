<?php

    include 'dbconn.php';

        $parentcompany = $_POST["parentcompany"];
        $id = $_POST['id'];

        $sqlQuery1 = "SELECT * FROM parentcompanydata WHERE parentcompany='".$parentcompany."';";
        $res11 = mysqli_query($conn,$sqlQuery1);

        if(mysqli_num_rows($res11) === 1) {
                echo "<script>";
                echo "alert('Parent Company with that name already exists!');";
                echo "window.location='addcompany.php';";
                echo "</script>";
        } else {

        $sql1 = "SELECT parentcompany FROM parentcompanydata WHERE id = '".$id."'";
        $res1 = mysqli_query($conn,$sql1);

        $result1 = mysqli_fetch_assoc($res1);

        // echo "<pre>";
        // print_r($result1);
        $client = $result1['parentcompany'];

        
        $sql = "UPDATE parentcompanydata SET parentcompany='".$parentcompany."' WHERE id = '".$id."'";
        $conn->query($sql);

        $sql2 = "SELECT parentcompany FROM parentcompanydata WHERE id = '".$id."'";
        $res2 = mysqli_query($conn,$sql2);
        $result2 = mysqli_fetch_assoc($res2);

        // echo "<pre>";
        // echo $result2['parentcompany'];

        $clientsql = "SELECT * FROM clientcompanydata WHERE parentcompany = '".$client."'";
        $clientRes1 = mysqli_query($conn,$clientsql);

        $clientR = mysqli_fetch_assoc($clientRes1);
        // echo "<pre>";
        // echo "Here";
        // echo $clientR['parentcompany'];
        // print_r($clientR);

        if($client == $clientR['parentcompany']) {
                // echo "Matches";
                $clientsql = "UPDATE clientcompanydata SET parentcompany='".$parentcompany."' WHERE parentcompany = '".$client."'";
                $clientRes1 = mysqli_query($conn,$clientsql);
        }
        echo "<script>
                alert('Parent details edited succesfully!'); 
                window.history.go(-2);
        </script>";
}
?>
