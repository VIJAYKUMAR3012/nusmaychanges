<?php

$sername = "localhost";
$user = "nustradetrack_admin";
$pass = "NUStradetrack@839";
$dbname = "nustradetrack_globalDB";

$conn = mysqli_connect($sername, $user, $pass, $dbname);

if(!$conn) {
    echo "Connection Failed...!";
    die();
}

?>